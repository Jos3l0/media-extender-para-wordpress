<?php
/*
Plugin Name: Media Extender
Description: Agrega una nueva columna con el peso y dimensiones de las imágenes en la vista de lista de medios.
Version: 1.0
Author: Equipo del Portal DGE Gob. de Mendoza
*/

// Agrega la nueva columna en la vista de lista de medios
// Añade nuevas columnas a la tabla de medios en el backend de WordPress
function media_extender_add_columns($columns) {
    // Añade una nueva columna llamada 'Peso' que mostrará el tamaño del archivo
    $columns['media_weight'] = 'Peso';
    
    // Añade una nueva columna llamada 'Dimensiones' que mostrará las dimensiones de la imagen (ancho x alto)
    $columns['media_dimensions'] = 'Dimensiones';
    
    // Devuelve el array de columnas modificado para que se refleje en la tabla de medios
    return $columns;
}
// Usa el filtro 'manage_media_columns' para modificar las columnas de la biblioteca de medios
add_filter('manage_media_columns', 'media_extender_add_columns');

// Muestra el contenido de las nuevas columnas en la biblioteca de medios
function media_extender_custom_column($column_name, $id) {
    // Comprueba si la columna actual es la columna de 'Peso'
    if ($column_name === 'media_weight') {
        // Obtiene la ruta completa del archivo adjunto (media) usando su ID
        $file = get_attached_file($id);
        
        // Si el archivo existe, calcula su tamaño en bytes y lo convierte a un formato legible (KB, MB, etc.)
        if ($file) {
            $file_size = filesize($file);  // Obtiene el tamaño del archivo en bytes
            echo size_format($file_size, 2);  // Convierte el tamaño a un formato legible (2 decimales)
        } else {
            echo 'N/A';  // Si no se encuentra el archivo, muestra 'N/A'
        }
    } 
    // Comprueba si la columna actual es la columna de 'Dimensiones'
    elseif ($column_name === 'media_dimensions') {
        // Obtiene los metadatos del archivo adjunto (generalmente solo imágenes tienen metadatos de dimensiones)
        $metadata = wp_get_attachment_metadata($id);
        
        // Si hay metadatos y existen las dimensiones de la imagen (ancho y alto), las muestra
        if ($metadata && isset($metadata['width']) && isset($metadata['height'])) {
            echo $metadata['width'] . 'x' . $metadata['height'] . ' px';  // Muestra el ancho x alto en píxeles
        } else {
            echo 'N/A';  // Si no hay metadatos o no es una imagen, muestra 'N/A'
        }
    }
}
// Usa la acción 'manage_media_custom_column' para definir el contenido de las nuevas columnas
// Se pasa un parámetro de prioridad 10 y se aceptan dos argumentos: el nombre de la columna y el ID del archivo adjunto
add_action('manage_media_custom_column', 'media_extender_custom_column', 10, 2);
